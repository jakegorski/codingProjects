#pragma once
#include <iostream>
using namespace std;

template <class Type>
class vertex
{
    struct node
    {
        Type item;
        node * link;
    };

public:
    class edgeIterator
    {
    public:
        friend class vertex;
        edgeIterator(); 
        edgeIterator(vertex<Type>::node * edge); 
        edgeIterator operator++(int);
        Type operator*();
        bool operator==(const edgeIterator&);
        bool operator!=(const edgeIterator&);
    private:
        node * current; // Address of node object where edgeIt points too
    };

    vertex();
    vertex(const vertex<Type>&);
    const vertex& operator=(const vertex<Type>&);
    ~vertex();
    edgeIterator begin();
    edgeIterator end();
    void addEdge(const Type&);
    friend ostream& operator<<(ostream& os, vertex<Type>& list){
        vertex<Type>::edgeIterator currentNode = list.begin();
        while(currentNode != list.end()){

        os << *currentNode << endl;
        currentNode++;

        }

        return os;
    }
private:
    node * neighbors; // Head of linked list, stores all neighbors of vertex
};


// Edge Iterator Class

// Default constructor sets current to NULL
template <class Type>
vertex<Type>::edgeIterator::edgeIterator(){

    current = nullptr;
}

// Constructor takes a node object and assigns to current
template <class Type>
vertex<Type>::edgeIterator::edgeIterator(vertex<Type>::node * edge){

    current = edge;
}

// Sets the iterator to point to the next node object, you will need to set current to
// point to the next node
template <class Type>
typename vertex<Type>::edgeIterator vertex<Type>::edgeIterator::operator++(int plus){

    current = current->link;
    return *this;
    
}

// Derefrences the IT, returns item field of the node that current points too
template <class Type>
Type vertex<Type>::edgeIterator::operator*(){

    return current->item;
}

// Compares address of left side IT with address of right side IT, true if same node
template <class Type>
bool vertex<Type>::edgeIterator::operator==(const vertex<Type>::edgeIterator& rhs){

    if(this == &rhs){

        return true;
    }
    if(this->current == rhs.current){

        return true;
    }

    return false;
}

// Compares address of left side IT with address of right side IT, false if same node
template <class Type>
bool vertex<Type>::edgeIterator::operator!=(const vertex<Type>::edgeIterator& rhs){

    return !(*this == rhs);
}

// Vertex Class


// Default Constructor sets neighbors to NULL
template <class Type>
vertex<Type>::vertex(){

    neighbors = nullptr;
}

// Copy Constructor deep copies neighbor list of the object passed into the constructor to the object that calls the constructor
template <class Type>
vertex<Type>::vertex(const vertex<Type>& copy){

    // Copied from myStack.h

    vertex<Type>::node * tc; //Head of list
	vertex<Type>::node * cc; //Current copy
	vertex<Type>::node * pc; //Previous copy 
	vertex<Type>::node * copyIndex; 
	tc = nullptr; 
	pc = nullptr;
	copyIndex = copy.neighbors; //Start copying copy's data, if any

	while(copyIndex != nullptr){

		cc = new vertex<Type>::node();
		cc -> item = copyIndex -> item;
		cc -> link = nullptr;
		if(tc == nullptr){	//If top copy is null, set it equal to current copy
			tc = cc;
		}
		if(pc != nullptr){	//If previous copy isn't null, set pc link to current
			pc -> link = cc;
		}
		pc = cc;
		copyIndex = copyIndex -> link;
	}

	neighbors = tc;

}

// Performs a deep copy of the right side object with the left side object (the object that calls
// the operator function)
template <class Type>
const vertex<Type>& vertex<Type>::operator=(const vertex<Type>& rhs){
    
    if(this == &rhs){
        return *this;
    }

    vertex<Type>::node * temp = neighbors;
	while(temp != nullptr){
		neighbors = neighbors->link;
		delete temp;
		temp = neighbors;
	}

    // Neighbors == NULL at this point

    vertex<Type>::node * tc; //Head of list
	vertex<Type>::node * cc; //Current copy
	vertex<Type>::node * pc; //Previous copy 
	vertex<Type>::node * copyIndex; 
	tc = nullptr; 
	pc = nullptr;
	copyIndex = rhs.neighbors; //Start copying copy's data, if any

	while(copyIndex != nullptr){

		cc = new vertex<Type>::node();
		cc -> item = copyIndex -> item;
		cc -> link = nullptr;
		if(tc == nullptr){	//If top copy is null, set it equal to current copy
			tc = cc;
		}
		if(pc != nullptr){	//If previous copy isn't null, set pc link to current
			pc -> link = cc;
		}
		pc = cc;
		copyIndex = copyIndex -> link;
	}

	neighbors = tc;
    
}

// Destructor that deallocates all nodes in neighbor list
template <class Type>
vertex<Type>::~vertex(){

    vertex<Type>::node * temp = neighbors;
	while(temp != nullptr){
		neighbors = neighbors->link;
		delete temp;
		temp = neighbors;
	}

}

// Returns a edgeIterator object whose current will be the head of the neighbor list for the vertex object
template <class Type>
typename vertex<Type>::edgeIterator vertex<Type>::begin(){

    vertex<Type>::edgeIterator start(neighbors);
    return start;

}


// Returns a edgeIterator object whose current will be assigned to NULL
template <class Type>
typename vertex<Type>::edgeIterator vertex<Type>::end(){

    vertex<Type>::edgeIterator last;
    return last;
}


// Adds a new node into the neighbor list (a head insert would be the best way to implement this)
template <class Type>
void vertex<Type>::addEdge(const Type& edge){

    vertex<Type>::node * newTop = new vertex<Type>::node();
	newTop->item = edge;
	newTop->link = neighbors;
	neighbors = newTop;

}
