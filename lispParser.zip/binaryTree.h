#pragma once
#include <fstream>
#include <iostream>
#include <cstdlib>
#include <string>
#include <sstream>
#include "myStack.h"
using namespace std;

template <class type>
struct binTreeNode
{
	binTreeNode();
	type item; //Stores the data in the node of the tree
	binTreeNode<type> * left;
	binTreeNode<type> * right;
};

template <class type>
void print(binTreeNode<type>*);

template <class type>
void print(type);

template <class type>
void readLISP(binTreeNode<type>*,  ifstream&);

//binTreeNode<int>* createNode(ifstream&);

template <class type>
bool evaluate(binTreeNode<type>*, int, int, myStack<type>&);

template <class type>
void destroyTree(binTreeNode<type>*);

template <class type>
void destroyTree_recursive(binTreeNode<type>*, myStack<binTreeNode<type>*>&);

////////////////////////////////////////////////////////////////////

template <class type>
binTreeNode<type>::binTreeNode(){
	left = right = nullptr;
}

template <class type>
void print(binTreeNode<type>* node){
	cout << node->item << " ";
}

template <class type>
void print(type node){
	cout << node << " ";
}

// This function reads from the ifstream infile variable and builds the tree, 
// the r pointer is pointing to some node in the current binary tree, you will 
// build this tree in a preorder type fashion
template <class type>
void readLISP(binTreeNode<type> * r,  ifstream& fin)
{
	int targetSum; //What we try to add up too
	int parentNode; 
	bool isLeft = true;
	bool eval_result;
	bool isTree = false; //Validate syntax
	int matches = -1;
	string inputLine;
	string output;
	string update;
	myStack<int> eval;
	myStack <binTreeNode<type>*> subTree;
	binTreeNode<type>* ogRoot = r;

	while(matches != 0 && !fin.eof()){ //End of file or end of expression

		getline(fin, inputLine); //Gets line from input stream 

		if(inputLine == "\r"){	//Blank line between trees
			break;
		}

		stringstream ss(inputLine);

		while(!ss.eof()){   //Runs until end of line is found
			getline(ss, output, '('); //Reads in values until an opening '(' is found

			if(!ss.good())
			{
				break;
			}
			else if(output == "")
			{
				continue;
			}

			if(matches == -1)
			{
				matches = 0;

				try{
					parentNode = stoi(output);	//Convert to int
					cout << "Target total: " << parentNode << endl;
					cout << endl;
					targetSum = parentNode;
				}
				catch(invalid_argument& error){
					cout << error.what() << endl;
					continue;
				}
			}
			else if(output.find(")") != string::npos){     //If closing ) found and not end of string
				for(int i = 0; i < output.length(); i++){   //Loop through length of string
					if(output[i] == ')'){     //If closing ) found, and is going right, pop
						matches--;

						if(!isLeft){
							subTree.pop();
						}

						if(subTree.size() != 1){
							isLeft = !isLeft; 
						}
					}
				}
			}
			else if(output.find("\n") == string::npos){
				if(!subTree.isEmpty()){    	//If subTree is not empty, then r is a subTree
					if(isLeft){			
						(subTree.top())->left = r;  //Update parents left subTree
					}
					else{
						(subTree.top())->right = r;	//Update parents right subTree
					}
				}
				r->item = stoi(output);
				subTree.push(r);

				r = new binTreeNode<type>(); //Begin new subTree
				isLeft = true;  //This is where to negotiate the spare node
			}

			cout << "\'" << output;
			cout << "\tGoing: "; 
				if(isLeft == 1){
					cout << "L" << " | "; 
				}
				else{
					cout << "R" << " | "; 
				}
			subTree.traverse(print);
			cout << endl;

			matches++;

			if(inputLine.length() + 1 < update.length()){

				inputLine = update.substr(inputLine.length() + 1);
			}
	    	}
	}

	eval_result = evaluate(ogRoot, 0, targetSum, eval);
	cout << "---------------------" << endl;
	cout << "Evaluation: ";
	if(eval_result == 1){
		cout << "Path found!" << endl;
		cout << "---------------------" << endl;
		cout << endl;
	}
	else{
		cout << "No path exists.." << endl;
		cout << "---------------------" << endl;
		cout << endl;
	}
}


template <class type>
bool evaluate(binTreeNode<type> * r, int runningSum, int targetSum, myStack<type>& path)
{
	bool left;
	bool right;

	if(r == nullptr)
	{
		return false;
	}

	runningSum += r->item;
	path.push(r->item);

	if(r->left == nullptr && r->right == nullptr){	//At a leaf node 
		cout << endl;
		cout << "Path to leaf: "; path.traverse(print); cout << "= " << runningSum << endl;
		cout << "Target Sum: " << targetSum << endl;
		path.pop();

		if(runningSum == targetSum){	//Checks running sum to the leaf
			path.push(r->item);
			cout << "-------------------------" << endl;
			cout << "Path to Target Sum Found!" << endl;
			path.traverse(print); cout << "= " << targetSum << endl;
			cout << "-------------------------" << endl;
			path.pop();
			return true;
		}
		else{
			cout << "No such path exists.." << endl;
			cout << endl;
			return false;
		}
	}

	left = evaluate(r->left, runningSum, targetSum, path); 
	right = evaluate(r->right, runningSum, targetSum, path);

	path.pop();

	return left || right;
}

// Deallocates the tree in a postorder type fashion
template <class type>
void destroyTree(binTreeNode<type> * r)
{
	myStack<binTreeNode<type>*> stack;

	destroyTree_recursive(r, stack);
}

template <class type>
void destroyTree_recursive(binTreeNode<type> *r, myStack<binTreeNode<type>*> &s)
{
	if(r == nullptr)
	{
		return;
	}

	s.push(r);

	if(r->left == nullptr && r->right == nullptr){	//At a leaf node 
		s.pop();
		delete r;
		return;
	}

	destroyTree_recursive(r->left, s);
	destroyTree_recursive(r->right, s);
	delete r;
}

