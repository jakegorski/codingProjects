/*
Jake Gorski 
Assignment 5 
This program will parse a LISP type language and
convert a LISP expression into a binary tree. Then find
a branch of that tree that equals the sum of an integer.
*/
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include "myStack.h"
#include "binaryTree.h"
using namespace std;


int main()
{
	binTreeNode<int> *root;
	ifstream fin;
	string fileName;
	int counter;
	//File Input
	cout << "Enter the file name: ";
	cin >> fileName;
	fin.open(fileName.c_str());

	while(fin.fail()){
		fin.clear();
		cout << "Incorrect filename, please enter again." << endl;
		cout << "Enter the file name: ";
		cin >> fileName;
		fin.open(fileName.c_str());
	}

	counter = 0;
//Read in entire file
	while(!fin.eof())
	{
		root = new binTreeNode<int>();
		root->item = 0;

		cout << endl;
		cout << "Attempt to read tree: " << ++counter << endl;

		readLISP(root, fin);

		destroyTree(root);
	}

	fin.close();
	
	return 0;
}

